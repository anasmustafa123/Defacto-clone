export default function Kids(){
    return (
        <h1>Kids</h1>
    )
}