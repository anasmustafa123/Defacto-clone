import { Children } from "react";

export default function Man(){
    return (
        <h1 className=" dark:bg-stone-900" >{Children}</h1>
    )
}