let man = [
  {
    url: "https://dfcdn.defacto.com.tr/480/M7666AZ_23AU_BK81_04_01.jpg",
    category: "T-shirt",
    productName: "Regular Fit T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/M7667AZ_23SP_BE633_04_01.jpg",
    category: "t-shirt",
    productName: "Regular Fit Crew Neck Basic T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A5234AX_23WN_KH461_04_02.jpg",
    category: "pullover",
    productName: "Standard Fit Crew Neck Knitwear Pullover",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z2453AZ_23SP_ER85_04_03.jpg",
    category: "Sweatshirt",
    productName: "Oversize Fit Hoodie Printed Sweatshirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z5851AZ_23SP_BG736_04_04.jpg",
    category: "jacket",
    productName: "Relax Fit College Collar Bomber Cardigan",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/M7125AZ_23SP_BE571_04_02.jpg",
    category: "t-shirt",
    productName: "Slim Fit Polo Neck Short Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/A4505AX_23SM_ER25_04_01.jpg",
    category: "blazer",
    productName: "Relax Fit Lined Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "shirt",
    productName: "Regular Fit Long Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/B0587AX_23WN_NV64_04_01.jpg",
    category: "pullover",
    productName: "Standard Fit Turtleneck Knitwear Pullover",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z5444AZ_23SM_BK81_04_01.jpg",
    category: "t-shiet",
    productName: "Regular Fit Crew Neck Printed T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/M7676AZ_23SP_NV120_04_02.jpg",
    category: "t-shirt",
    productName: "Regular Fit Polo T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/A5801AX_23AU_OG79_04_01.jpg",
    category: "sweatshirt",
    productName: "Oversize Fit Printed Long Sleeve Sweatshirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "coat",
    productName: "Slim Fit Recycled Filling Coat",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/N9902AZ_23WN_GR110_04_01.jpg",
    category: "pullover",
    productName: "Standard Fit Crew Neck Knitwear Pullover",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "sweatshirt",
    productName: "Chicago Bulls Licensed Sweatshirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Y0902AZ_23AU_GN756_04_02.jpg",
    category: "pullover",
    productName: "Slim Fit Polo Collar Pullover",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/V8406AZ_23SM_BK27_04_02.jpg",
    category: "shirt",
    productName: "Modern Fit aerobics Short Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A3124AX_23SM_ER105_03_02.jpg",
    category: "t-shirt",
    productName: "Regular Fit Crew Neck Printed T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/T7999AZ_23SP_NM7_04_02.jpg",
    category: "t-shirt",
    productName: "Regular Fit Polo T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/N5923AZ_23HS_BE707_04_01.jpg",
    category: "short",
    productName: "Short Swimming Short",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/X4008AZ_22WN_BK27_04_02.jpg",
    category: "jacket",
    productName: "Oversize Fit Faux Leather Faux Leather",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "jacket",
    productName: "Oversize Fit Sustainable Agriculture Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/N9693AZ_22WN_BK27_04_02.jpg",
    category: "coat",
    productName: "Slim Fit Faux Leather Faux Leather Coat",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A9912AX_23AU_NM39_04_01.jpg",
    category: "jacket",
    productName: "Oversize Fit Sustainable Agriculture Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "jacket",
    productName: "Regular Fit Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "jacket",
    productName: "Modern Fit Blazer Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Y7687AZ_22AU_NM39_04_03.jpg",
    category: "jacket",
    productName: "Relax Fit College Collar Bomber Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/X8868AZ_22AU_NM34_04_01.jpg",
    category: "jacket",
    productName: "Slim Fit Jean Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "jacket",
    productName: "Slim Fit Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "coat",
    productName: "Slim Fit Faux Leather Faux Leather Coat",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/N0503AZ_23SP_NV64_04_03.jpg",
    category: "blazer jacket",
    productName: "Slim Fit Textured Blazer Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "jacket",
    productName: "Slim Fit Textured Blazer Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/Z7667AZ_23SM_KH163_03_01.jpg",
    category: "blazer",
    productName: "Regular Fit linen Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/W9254AZ_23SP_NV64_04_03.jpg",
    category: "blazer",
    productName: "Slim Fit Lined Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/X4844AZ_22SM_BN132_04_01.jpg",
    category: "blazer",
    productName: "Slim Fit Half Lining Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z8075AZ_23SM_NV147_04_01.jpg",
    category: "blazer",
    productName: "Regular Fit linen Half Lining Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Y7473AZ_22AU_BN207_04_01.jpg",
    category: "blazer",
    productName: "Slim Fit Lined Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/V5602AZ_22WN_GR210_04_02.jpg",
    category: "blazer",
    productName: "Modern Fit Lined Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "blazer",
    productName: "Modern Fit Lined Blazer",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Y2571AZ_22AU_BK81_04_02.jpg",
    category: "vest",
    productName: "Regular Fit Dog Collar Vest",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/U4176AZ_22WN_GR91_04_01.jpg",
    category: "vest",
    productName: "Slim Fit Vest",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A5353AX_23AU_ER42_04_01.jpg",
    category: "vest",
    productName: "Regular Fit Discovery Licensed Dog Collar Vest",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "vest",
    productName: "Regular Fit Vest",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "vest",
    productName: "Slim Fit Vest",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A3137AX_23SM_BK81_04_01.jpg",
    category: "T-shirt",
    productName: "Slim Fit Crew Neck Printed T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A3134AX_23SM_GR91_04_01.jpg",
    category: "t-shirt",
    productName: "Slim Fit Crew Neck Printed T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z3092AZ_23SP_BG714_04_02.jpg",
    category: "t-shirt",
    productName: "Slim Fit Crew Neck Printed T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "T-shirt",
    productName: "Long Muscle Fit Crew Neck Printed T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/Z2450AZ_23SP_WT34_04_04.jpg",
    category: "T-shirt",
    productName: "Comfort Fit Crew Neck T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/M7666AZ_23AU_BK81_04_01.jpg",
    category: "T-shirt",
    productName: "Regular Fit T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A2634AX_23SM_WT34_04_02.jpg",
    category: "T-shirt",
    productName: "Regular Fit Crew Neck T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z2147AZ_22AU_IN234_04_01.jpg",
    category: "short",
    productName: "Slim Fit Woven Woven Short",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/W7965AZ_23SM_GR362_04_02.jpg",
    category: "short",
    productName: "Slim Fit Slim Leg Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/W2467AZ_23SM_AR94_04_01.jpg",
    category: "short",
    productName: "Regular Fit Cargo Pocket Bermuda Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Y4950AZ_22HS_AR111_04_01.jpg",
    category: "short",
    productName: "Slim Fit Short",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/W7965AZ_23SM_BK81_04_02.jpg",
    category: "short",
    productName: "Slim Fit Slim Leg Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "short",
    productName: "Regular Fit Lace-Up Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/W2467AZ_23SM_GR377_04_01.jpg",
    category: "short",
    productName: "Regular Fit Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/Z9347AZ_23SM_WT55_04_02.jpg",
    category: "shirt",
    productName: "Modern Fit Long Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Y4004AZ_22WN_GR210_04_01.jpg",
    category: "shirt",
    productName: "Regular Fit Flanel Long Sleeve Shirt",
  },
];
const getRandomRating = () => {
  return parseInt(Math.random() * 5);
};
const getRandomPrice = () => {
  return `$${parseInt(70 + Math.random() * 300)} `;
};
const getRandomDiscount = () => {
  return `${parseInt(Math.random() * 100)}%`;
};

man.forEach((item) => {
  item["gender"] = "m";
  item["productRating"] = getRandomRating();
  item["originalPrice"] = getRandomPrice();
  item["percentOff"] = getRandomDiscount();
  item["price"] = item["originalPrice"];
  item["key"] = parseInt(Math.random() * 10000);
});

export { man };
