let kids = [
  {
    url: "https://dfcdn.defacto.com.tr/480/K1686A6_23AU_BK81_04_01.jpg",
    category: "T-shirt",
    productName: "Regular Fit Long Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/V1186A6_23AU_GN671_04_01.jpg",
    category: "T-shirt",
    productName: "Regular Fit Long Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/V1186A6_23AU_BE766_04_02.jpg",
    category: "T-shirt",
    productName: "Regular Fit Long Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/V1186A6_23AU_GR400_04_01.jpg",
    category: "newSeason",
    productName: "Regular Fit Long Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/K1686A6_23AU_WT34_04_01.jpg",
    category: "newSeason",
    productName: "Regular Fit Long Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A9296A8_23AU_RD70_04_01.jpg",
    category: "newSeason",
    productName: "Printed Short Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/A4464A8_23AU_WT16_04_02.jpg",
    category: "newSeason",
    productName: "Oversize Fit Long Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/A5608A8_23AU_ER134_04_01.jpg",
    category: "newSeason",
    productName: "Oversize Fit Mickey & Minnie Licensed Short Sleeve T-shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A5605A8_23AU_IN34_04_02.jpg",
    category: "newSeason",
    productName: "Oversize Fit Mickey & Minnie Licensed Short Sleeve T-shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A1871A8_23AU_BK27_04_04.jpg",
    category: "coat",
    productName: "Tippet Faux Leather Coat",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A3782A8_23AU_NM39_04_02.jpg",
    category: "newSeason",
    productName: "Bomber Jean Jacket",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/V4325A6_23AU_NM34_04_01.jpg",
    category: "pant",
    productName: "Wide Leg Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "pant",
    productName: "Wide Leg Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "pant",
    productName: "Straight Fit Jean Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A3906A8_23AU_NM34_04_01.jpg",
    category: "pant",
    productName: "Tapered Fit Jean Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A3780A8_23WN_NM36_04_01.jpg",
    category: "newSeason",
    productName: "Cargo Fit Jean Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A5550A8_23AU_NM40_04_01.jpg",
    category: "newSeason",
    productName: "Slim Fit Jean Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "newseason",
    productName: "Slim Fit Jean Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "newSeason",
    productName: "Wide Leg Jean Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "newSeason",
    productName: "Slim Fit Jean Pants",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/B1596A8_23AU_BK23_04_01.jpg",
    category: "newSeason",
    productName: "Boy Flat Sole Faux Leather Boots",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/X2137A6_23HS_NM39_04_02.jpg",
    category: "short",
    productName: "Girls Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A3208A8_23SM_NV135_04_02.jpg",
    category: "short",
    productName: "Regular Fit Short",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "T-shirt",
    productName: "Boy Regular Fit Polo Neck Pique Short Sleeved Polo T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "short",
    productName: "Regular Fit Short",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/Z8003A6_23SM_GN279_04_01.jpg",
    category: "T-shirt",
    productName: "Boy Regular Fit Crew Neck Printed Short Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A1606A8_23SM_PN82_04_01.jpg",
    category: "dress",
    productName: "Regular Fit Short Sleeve Dress",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "shirt",
    productName: "Girls Crop Tencel Short Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "short",
    productName: "Girls' Sweatshirt Fabric Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A1460A8_23HS_WT34_04_04.jpg",
    category: "skirt",
    productName: "Girl Wowen Fabrics Relax Fit Skirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z5754A6_23SM_AR58_04_01.jpg",
    category: "short",
    productName: "Boy Regular Fit Combed Cotton Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "T-shirt",
    productName: "Girl Regular Fit Short Sleeve T-Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/Z5364A6_23SM_BE343_04_01.jpg",
    category: "shirt",
    productName: "Boys Straight Collar Linen Look Short Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z5697A6_23SP_BG285_04_02.jpg",
    category: "skirt",
    productName: "Girl Regular Fit Knitted Skirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/W5824A6_23HS_NM28_04_01.jpg",
    category: "short",
    productName: "Girl Mom Fit Ripped Detailed Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z5822A6_23HS_PN253_04_01.jpg",
    category: "short",
    productName: "Girl Beach Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "short",
    productName: "Boys Swimming Shorts",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/Z4933A6_23SP_AR215_04_03.jpg",
    category: "dress",
    productName: "Girl Crew Neck Printed Sweat Dress",
  },

  {
    url: "https://dfcdn.defacto.com.tr/768/A0083A8_23SM_GN1014_04_05.jpg",
    category: "blous",
    productName: "Girl Square Collar Short Sleeve Blouse",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "dress",
    productName: "Girl Short Sleeve Dress",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/X7564A6_22WN_BE52_04_02.jpg",
    category: "shirt",
    productName: "Oversize Fit Long Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/B1708A8_23AU_PR249_04_01.jpg",
    category: "shirt",
    productName: "Regular Fit Long Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A7292A8_23HS_NV71_04_02.jpg",
    category: "shirt",
    productName: "Boy Oversize Viscose Short Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "shirt",
    productName: "Regular Fit Long Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/A6312A8_23AU_WT32_04_02.jpg",
    category: "NewSeason",
    productName: "Oversize Fit Long Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Y4208A6_22WN_GN1116_04_02.jpg",
    category: "shirt",
    productName: "Boys Oversize Fit Long Sleeve Flannel Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/AssetsV2/dist/img/placeholders/placeholder.svg",
    category: "short",
    productName: "Boy Oversize Fit Polo Neck Viscose Short Sleeve Shirt",
  },

  {
    url: "https://dfcdn.defacto.com.tr/480/Z0012A6_22HS_BE693_04_02.jpg",
    category: "shirt",
    productName: "Boy's Striped Short Sleeve Shirt",
  },
];
const getRandomRating = () => {
  return parseInt(Math.random() * 5);
};
const getRandomPrice = () => {
  return `$${parseInt(70 + Math.random() * 300)} `;
};
const getRandomDiscount = () => {
  return `${parseInt(Math.random() * 100)}%`;
};

kids.forEach((item) => {
  item["gender"] = "k";
  item["productRating"] = getRandomRating();
  item["originalPrice"] = getRandomPrice();
  item["percentOff"] = getRandomDiscount();
  item["price"] = item["originalPrice"];
  item["key"] = parseInt(Math.random() * 10000);
});

export { kids };
